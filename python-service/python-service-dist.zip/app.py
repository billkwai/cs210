#!/usr/bin/env python
from __future__ import print_function
from flask import Flask, jsonify, abort, request
from flask_cors import CORS, cross_origin

#import mysql.connector
#from mysql.connector import errorcode

import logging
import pymysql
import os
import hashlib, binascii, base64
#import bcrypt
#from argon2 import PasswordHasher
#import bcrypt

app = Flask(__name__)
CORS(app)
cors = CORS(app, resources={r"/api/*": {"origins": "*","methods":"POST,DELETE,PUT,GET,OPTIONS"}})


#DB_NAME = 'employees'

TABLES = {}
TABLES['employees'] = (
    "CREATE TABLE `employees` ("
    "  `emp_no` int(11) NOT NULL AUTO_INCREMENT,"
    "  `birth_date` date NOT NULL,"
    "  `first_name` varchar(14) NOT NULL,"
    "  `last_name` varchar(16) NOT NULL,"
    "  `gender` enum('M','F') NOT NULL,"
    "  `hire_date` date NOT NULL,"
    "  PRIMARY KEY (`emp_no`)"
    ") ENGINE=InnoDB")



def creatConnection():
    # Read MySQL Environment Parameters
    connectString = os.environ.get('MYSQLCS_CONNECT_STRING', '129.150.120.63:/mydatabase')
    hostname = connectString[:connectString.index(":")]#'129.150.120.63'#
    database = connectString[connectString.index("/")+1:]#'mydatabase'#
    print("Hostname = "+hostname+", database = "+database)
    #return os.environ.get('MYSQLCS_MYSQL_PORT', '3306') + os.environ.get('MYSQLCS_USER_NAME', 'root') + os.environ.get('MYSQLCS_USER_PASSWORD', '') + hostname+' '+database+'\n'
    #return 'Inside mid of creatConnection'
    #print (pymysql.cursors.DictCursor == None, pymysql.cursors.DictCursor)
    #return 'Pre created conn'
    #cnx = mysql.connector.connect(user='root', #os.environ.get('MYSQLCS_USER_NAME', 'root'),
     #                         password=os.environ.get('MYSQLCS_USER_PASSWORD', 'lynx1N{}'),
      #                        host=hostname,
       #                       database=db)

    port=int(os.environ.get('MYSQLCS_MYSQL_PORT', '3036'))
    user=os.environ.get('MYSQLCS_USER_NAME', 'root')
    passwd=os.environ.get('MYSQLCS_USER_PASSWORD', 'lynx1N{}')
    #return "Hostname = "+hostname+", database = "+database+", port = "+str(port)+", user = "+user+", passwd = "+passwd
    conn = pymysql.connect(host=hostname, 
                           port=port,
                           user=user, 
                           passwd=passwd,
                           db=database,
                           cursorclass=pymysql.cursors.DictCursor)
    print( "Hostname = "+hostname+", database = "+database+", port = "+str(port)+", user = "+user+", passwd = "+passwd)


    #return 'Inside created conn'
    #conn.close()
    return conn;
    #return cnx;

@app.route('/')
def index():
    return 'The application is running!'
    
@app.route('/players/setupdb')
def setupDB():
    print("Reached players/setupdb endpoint")
    #return creatConnection()
    conn = creatConnection()
    return conn
    #cnx = creatConnection()
    cur = conn.cursor()
    #cursor = cnx.cursor()

#    for name, ddl in TABLES.items():
 #       try:
  #          print("Creating table {}: ".format(name), end='')
   #         cursor.execute(ddl)
    #    except mysql.connector.Error as err:
     #       if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
      #          print("already exists")
       #     else:
        #        print(err.msg)
        #else:
         #   print("OK")

    cur.execute('''CREATE TABLE PLAYERS (
                  ID INTEGER NOT NULL AUTO_INCREMENT,
                  FIRSTNAME VARCHAR(255),
                  LASTNAME VARCHAR(255),
                  PASSWORD VARCHAR(255),
                  EMAIL VARCHAR(255),
                  PHONE VARCHAR(255),
                  BIRTHDATE VARCHAR(10),
                  COLLEGE VARCHAR(255),
                  COMPANY VARCHAR(255),
                  PRIMARY KEY (ID)
                  ); ''') 
    conn.commit()
    cur.close()
    #cursor.close()
    #cnx.close()
    conn.close()
    return 'The PLAYERS table was created succesfully'
    
@app.route('/players')
def players():
    print("Reached players endpoint")
    conn = creatConnection()
    cur = conn.cursor()
    cur.execute('''SELECT * FROM PLAYERS''')
    results = cur.fetchall()    
    cur.close()
    conn.close()
    return jsonify( results)    

@app.route('/players/<int:player_id>', methods=['GET'])
def get_player(player_id):
    conn = creatConnection()
    cur = conn.cursor()
    cur.execute('''SELECT ID, FIRSTNAME, LASTNAME, EMAIL, PHONE, BIRTHDATE, TITLE, DEPARTMENT FROM PLAYERS WHERE ID = %s'''%(player_id))
    rv = cur.fetchone()    
    if rv is None:
        abort(404)
    cur.close()
    conn.close()
    return jsonify( rv) 

@app.route('/players', methods=['POST'])
def create_player():
    conn = creatConnection()
    cur = conn.cursor()
    try:
        #ph = PasswordHasher()
        #hash = ph.hash(request.json['password'])
        #hashed_pw = bcrypt.hashpw(bytes(request.json['password'], encoding='utf-8'), bcrypt.gensalt())
        hashed_pw = hashlib.pbkdf2_hmac('sha256', bytes(request.json['password'], encoding='utf-8'), os.urandom(16), 100000)
        cur.execute('''INSERT INTO PLAYERS (FIRSTNAME, LASTNAME, PASSWORD, EMAIL, PHONE, BIRTHDATE, COLLEGE, COMPANY) 
                    VALUES('%s','%s','%s','%s','%s','%s','%s', '%s') '''%(request.json['firstName'],request.json['lastName'],
                        binascii.hexlify(hashed_pw).decode("utf-8"),#hash,
                    request.json['email'],request.json['phone'],request.json['birthDate'],request.json['college'],request.json['company']))    
        conn.commit()
        message = {'status': 'New player record is created succesfully'}
        cur.close()  
    except Exception as e:
        logging.error('DB exception: %s' % e)
        message = {'status': 'The creation of the new player failed. DB exception: %s' % e}
    conn.close()
    return jsonify(message)

@app.route('/players/<int:player_id>', methods=['PUT'])
def update_player(player_id):
    conn = creatConnection()
    cur = conn.cursor()
    try:
        cur.execute('''UPDATE PLAYERS SET FIRSTNAME='%s', LASTNAME='%s', PASSWORD='%s', EMAIL='%s', PHONE='%s', BIRTHDATE='%s', COLLEGE='%s', COMPANY='%s' 
                   WHERE ID=%s '''%(request.json['firstName'],request.json['lastName'], request.json['password'],
                   request.json['email'],request.json['phone'],request.json['birthDate'],request.json['college'],request.json['company'],player_id))    
        conn.commit()
        message = {'status': 'The player record is updated succesfully'}
        cur.close()  
    except Exception as e:
        logging.error('DB exception: %s' % e)   
        message = {'status': 'Player update failed.'}
    conn.close()
    return jsonify(message)

@app.route('/players/<int:player_id>', methods=['DELETE'])
def delete_player(player_id):
    conn = creatConnection()
    cur = conn.cursor()
    try:
        cur.execute('''DELETE FROM PLAYERS WHERE ID=%s '''%(player_id))    
        message = {'status': 'The player record is deleted succesfully'}
        conn.commit()
        cur.close()  
    except Exception as e:
        logging.error('DB exception: %s' % e)   
        message = {'status': 'Player delete failed.'}
    conn.close()
    return jsonify(message)

if __name__ == '__main__':
      app.run(host='0.0.0.0', port=int(os.environ.get('PORT', '8080')))
